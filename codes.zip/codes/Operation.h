#include "Interface.h"

// Definition of pin connections
const uint8_t buzzer_pin=5, red_ind_pin=6, green_ind_pin=7, backlight_pin=A0, sense_pin=A1;