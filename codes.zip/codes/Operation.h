#include "Interface.h"
#include "Sense.h"
#include "Communication.h"

// Definition of pin connection
const uint8_t btn_pin=2;

// Decralation of usefull variables


// Method to handle Interrupt button
void listenBtn(){
  button = true;
}

// Method to commbine all operations
void operation(){

}